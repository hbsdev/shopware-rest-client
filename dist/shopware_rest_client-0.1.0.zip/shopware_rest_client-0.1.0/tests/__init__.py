# -*- coding: utf-8 -*-

"""
Tests for the swapi module.

http://pytest.org/latest/getting-started.html
http://pytest.org/latest/goodpractises.html
http://pytest.org/latest/example/index.html

Pytest’s powerful fixture mechanism which leverages the concept of dependency injection:
http://pytest.org/latest/fixture.html#fixture
"""
