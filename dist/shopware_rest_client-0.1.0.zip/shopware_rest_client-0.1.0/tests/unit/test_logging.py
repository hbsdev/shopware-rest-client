# -*- coding: utf-8 -*-

class TestLogging():
  def test_logging(self):
    import easylog
