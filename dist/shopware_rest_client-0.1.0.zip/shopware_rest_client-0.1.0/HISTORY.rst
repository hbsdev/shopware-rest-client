.. :changelog:

History
-------

0.1.0 (2015-05-26)
------------------

* Proof of concept
