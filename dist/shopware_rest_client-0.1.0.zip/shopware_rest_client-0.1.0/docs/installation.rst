============
Installation
============

At the command line::

    $ easy_install shopware_rest_client

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv shopware_rest_client
    $ pip install shopware_rest_client
