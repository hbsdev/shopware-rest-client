========
Usage
========

To use Shopware REST API client in a project::

    import shopware_rest_client
