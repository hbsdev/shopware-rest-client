# -*- coding: utf-8 -*-

def ok():
  return "OK"