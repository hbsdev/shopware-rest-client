.. :changelog:

History
-------

0.2.0 (2015-09-02)
------------------

* Article resource

0.1.0 (2015-05-26)
------------------

* Proof of concept
